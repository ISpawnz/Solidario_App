package com.carlos.solidario;

public class TelaAnuncio {
}
